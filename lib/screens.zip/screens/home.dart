import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget{
  final String name,email,displaypicURL;
  HomeScreen({this.name, this.email, this.displaypicURL });
  @override
  _HomeScreenState createState() => _HomeScreenState();
  
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
      ),
drawer: Drawer(child: ListView(
  children: <Widget>[
    
    UserAccountsDrawerHeader(
      accountName: Text(
        widget.name,
      ),
      accountEmail: Text(
        widget.email,
      ),
      currentAccountPicture: CircleAvatar(
        backgroundImage: NetworkImage(
          widget.displaypicURL,
        ),
      )
      
    )
  ],
),),
    );
    
  }
}